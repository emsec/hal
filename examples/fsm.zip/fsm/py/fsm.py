from hal_plugins import solve_fsm

fsm_state_register = 2
fsm_transition_logic = 3

fsm_state_register_gates = netlist.get_module_by_id(fsm_state_register).get_gates()
fsm_transition_logic_gates = netlist.get_module_by_id(fsm_transition_logic).get_gates()


res = solve_fsm.solve_fsm(
    netlist,
    fsm_state_register_gates,
    fsm_transition_logic_gates,
    dict(),
    hal_py.ProjectManager.instance().get_project_directory().get_canonical_path()
    / "fsm.dot",
)
