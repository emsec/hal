# Recovers the state transition graph of the FSM and shows it in the dot viewer.
#
# Expects the two modules you created by hand, so that the solver knows which flip flops hold the
# state and which gates compute the next one, plus the nets that carry the outputs of the machine.
# Look the IDs up in the modules widget and in the selection details, and enter them below.

from hal_plugins import solve_fsm
from hal_plugins import dot_viewer

STATE_REGISTER_MODULE_ID = 2
TRANSITION_LOGIC_MODULE_ID = 3

# The outputs are given as nets, not as a module: an output does not need a gate of its own, and here
# OUTPUT_0 comes straight off a flip flop without passing through the output logic at all. Each entry
# is one output; group several net IDs in one entry to describe a multi-bit output.
OUTPUT_NET_IDS = [[9], [10]]


def get_module_by_id(module_id, what):
    module = netlist.get_module_by_id(module_id)
    if module is None:
        print(
            "there is no module with ID {} to use as the {}. Look the ID up in the modules "
            "widget and adjust the constants at the top of this script.".format(module_id, what)
        )
    return module


def get_nets_by_id(net_ids):
    nets = []
    for net_id in net_ids:
        net = netlist.get_net_by_id(net_id)
        if net is None:
            print(
                "there is no net with ID {} to use as an output. Select the net and look its ID up in "
                "the selection details, then adjust OUTPUT_NET_IDS at the top of this script.".format(net_id)
            )
            return None
        nets.append(net)
    return nets


state_register = get_module_by_id(STATE_REGISTER_MODULE_ID, "state register")
transition_logic = get_module_by_id(TRANSITION_LOGIC_MODULE_ID, "transition logic")
output_nets = [get_nets_by_id(ids) for ids in OUTPUT_NET_IDS]

if None not in (state_register, transition_logic) and None not in output_nets:
    # An output is named after the net that carries its least significant bit.
    outputs = [(nets[0].name, nets) for nets in output_nets]

    print(
        "solving FSM from {} state flip flops, {} transition gates and {} outputs...".format(
            len(state_register.get_gates()), len(transition_logic.get_gates()), len(outputs)
        )
    )

    config = (
        solve_fsm.Configuration(netlist)
        .with_state_register(state_register.get_gates())
        .with_transition_logic(transition_logic.get_gates())
        .with_outputs(outputs)
    )

    graph = solve_fsm.solve_fsm(config)

    if graph is None:
        print("could not solve the FSM, see the log widget for the reason.")
    else:
        # Everything the solver found, with no condition cut short. graph.write_txt(path) writes the
        # same text to a file.
        print(graph.to_string())

        graph_path = (
            hal_py.ProjectManager.instance().get_project_directory().get_canonical_path()
            / "fsm.dot"
        )

        # Solving does not write anything, rendering the graph is a separate step.
        graph.generate_dot_graph(graph_path)
        print("wrote {}".format(graph_path))

        # Show the graph. Needs the dot_viewer plugin to be enabled in the plugin manager.
        if not dot_viewer.load_dot_file(graph_path, "solve_fsm"):
            print(
                "could not open the graph in the dot viewer. Is the dot_viewer plugin enabled "
                "in the plugin manager? The graph has been written to {} either way.".format(graph_path)
            )
