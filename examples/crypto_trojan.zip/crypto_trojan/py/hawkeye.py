# Locate and identify the symmetric cryptographic primitive in this netlist.
#
# HAWKEYE works purely structurally: it looks for a register whose bits feed
# back into themselves through combinational logic, which is the signature of a
# round-based cipher. It is not told which algorithm to expect. Once such a
# state register is found, the round function around it is isolated and HAWKEYE
# tries to identify the S-box inside it.
#
# On this netlist the expected outcome is that one of the two 128 bit
# candidates is identified as AES.

import os
import hal_py
from hal_plugins import hawkeye, netlist_preprocessing


# --- preprocessing -----------------------------------------------------------

# The flip-flops of this gate library (FD1) have both a Q and a QN output. A
# gate driving two nets cannot be handled by the S-box identification, so the
# inverted outputs are rerouted through explicit inverter gates first. Without
# this step the analysis still finds AES, but logs a number of errors on the
# way.
rerouted = netlist_preprocessing.unify_ff_outputs(netlist)
print("rerouted %s inverted flip-flop output(s)" % rerouted)


# --- locate the S-box database shipped with HAL ------------------------------

base_dir = str(hal_py.CoreUtils.get_base_directory())

sbox_db_path = ""
for path in [os.path.join(base_dir, "share", "hal", "sbox-database.json"),
             os.path.join(base_dir, "..", "plugins", "hawkeye", "sbox-database.json")]:
    if os.path.isfile(path):
        sbox_db_path = os.path.normpath(path)
        break

if not sbox_db_path:
    print("could not find sbox-database.json - set sbox_db_path manually")
    raise SystemExit

sbox_db = hawkeye.SBoxDatabase.from_file(sbox_db_path)


# --- 1. detect candidate state registers -------------------------------------

config = hawkeye.DetectionConfiguration()
config.control = hawkeye.DetectionConfiguration.Control.CHECK_NETS
config.components = hawkeye.DetectionConfiguration.Components.NONE
config.timeout = 10
config.min_register_size = 10

candidates = hawkeye.detect_candidates(netlist, [config], 40)
print("detected %d state register candidate(s)" % len(candidates))


# --- 2. isolate the round function and identify its S-box --------------------

for i, candidate in enumerate(candidates):
    print("")
    print("candidate %d: %d bit state register" % (i, candidate.get_size()))

    # copies the state registers and the logic between them into a netlist of
    # their own, so the round function can be analyzed in isolation
    round_candidate = hawkeye.RoundCandidate.from_register_candidate(candidate)
    if round_candidate is None:
        print("   could not isolate a round function")
        continue

    sbox_candidates = hawkeye.locate_sboxes(round_candidate)
    if not sbox_candidates:
        print("   no S-box candidates found")
        continue

    print("   %d S-box candidate(s) to check" % len(sbox_candidates))

    # structural search is cheap and over-approximates, so most candidates do
    # not identify - stop at the first one that does
    identified = ""
    for sbox_candidate in sbox_candidates:
        identified = hawkeye.identify_sbox(sbox_candidate, sbox_db)
        if identified:
            break

    if identified:
        print("   >>> identified S-box: %s" % identified)
    else:
        print("   no known S-box identified")
