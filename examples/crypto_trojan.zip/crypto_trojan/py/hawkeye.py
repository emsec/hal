# Locate and identify the symmetric cryptographic primitive in this netlist.
#
# HAWKEYE works purely structurally: it looks for a register whose bits feed
# back into themselves through combinational logic, which is the signature of a
# round-based cipher. It is not told which algorithm to expect. Once such a
# state register is found, the round function computing its next state is
# determined and HAWKEYE tries to identify the S-box inside it.
#
# On this netlist the expected outcome is that one of the two 128 bit
# candidates is identified as AES.

import os
import hal_py
from hal_plugins import hawkeye


# --- locate the S-box database shipped with HAL ------------------------------

base_dir = str(hal_py.CoreUtils.get_base_directory())

sbox_db_path = ""
for path in [os.path.join(base_dir, "share", "hal", "sbox-database.json"),
             os.path.join(base_dir, "..", "plugins", "hawkeye", "sbox-database.json")]:
    if os.path.isfile(path):
        sbox_db_path = os.path.normpath(path)
        break

if not sbox_db_path:
    print("could not find sbox-database.json - set sbox_db_path manually")
    raise SystemExit

sbox_db = hawkeye.SBoxDatabase.from_file(sbox_db_path)


# --- 1. detect candidate state registers -------------------------------------

config = hawkeye.DetectionConfiguration()
config.control = hawkeye.DetectionConfiguration.Control.CHECK_NETS
config.components = hawkeye.DetectionConfiguration.Components.NONE
config.timeout = 10
config.min_register_size = 10

candidates = hawkeye.CipherCandidate.detect(netlist, [config], 40)
if candidates is None:
    print("candidate detection failed, see the log widget for the reason")
    raise SystemExit

print("detected %d state register candidate(s)" % len(candidates))


# --- 2. determine the round function and identify its S-box ------------------

for i, candidate in enumerate(candidates):
    print("")
    print("candidate %d: %d bit state register" % (i, candidate.get_size()))

    # determines the combinational logic computing the next state from the
    # state register, which is where the S-boxes are searched for
    if not candidate.build_round_function():
        print("   could not determine the round function")
        continue

    sboxes = candidate.locate_sboxes()
    if not sboxes:
        print("   no S-box candidates found")
        continue

    print("   %d S-box candidate(s) to check" % len(sboxes))

    # structural search is cheap and over-approximates, so most candidates do
    # not identify - stop at the first one that does
    identified = ""
    for sbox in sboxes:
        identified = candidate.identify_sbox(sbox, sbox_db)
        if identified:
            break

    if identified:
        print("   >>> identified S-box: %s" % identified)
    else:
        print("   no known S-box identified")
