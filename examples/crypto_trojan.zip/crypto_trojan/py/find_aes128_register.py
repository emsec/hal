import os
from hal_plugins import dataflow

# create output directory if not exists
dataflow_outdir = os.getcwd() + "/dataflow"
if not os.path.exists(dataflow_outdir):
    os.mkdir(dataflow_outdir)

# configure and run dataflow analysis
config = dataflow.Configuration(netlist)
config = config.with_flip_flops()
config.expected_sizes = [128]
res = dataflow.analyze(config)

res.write_dot(dataflow_outdir + "/graph.dot")
res.create_modules() 
