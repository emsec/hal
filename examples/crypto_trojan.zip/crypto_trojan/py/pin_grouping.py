# DO NOT CHANGE ANYTHING IN THIS SCRIPT

m = netlist.get_top_module()

for groupname in ["PLAINTEXT", "KEY", "CIPHERTEXT"]:
    for igroup in reversed(range(16)):
        pins = []
        for i in range(8):
            ipin = igroup*8 + i
            pins.append(m.get_pin_by_name("%s_%d" % (groupname, ipin)))
        m.create_pin_group("%s_BYTE_%d" % (groupname, igroup), pins)