import time

sim_gates = netlist.get_gates()

from hal_plugins import netlist_simulator_controller

pl_sim_ctrl = hal_py.plugin_manager.get_plugin_instance("netlist_simulator_controller")

ctrl_sim = pl_sim_ctrl.create_simulator_controller() 
eng = ctrl_sim.create_simulation_engine("verilator")
eng.set_engine_property("num_of_threads", "4")
ctrl_sim.add_gates(sim_gates)


# get control nets
top_mod = netlist.get_top_module()
start_net = top_mod.get_pin_by_name("START").get_net()
done_net = top_mod.get_pin_by_name("DONE").get_net()


# add clock
clk_net = top_mod.get_pin_by_name("CLK").get_net()
period = 1000
ctrl_sim.add_clock_period(clk_net, period)


# initialize GND and VCC
ctrl_sim.set_input(netlist.get_net_by_id(1), hal_py.BooleanFunction.Value.ZERO)
ctrl_sim.set_input(netlist.get_net_by_id(2), hal_py.BooleanFunction.Value.ONE)


# get data in-/outputs
key_pg = top_mod.get_pin_group_by_name("KEY")
plaintext_pg = top_mod.get_pin_group_by_name("PLAINTEXT")
output_pg = top_mod.get_pin_group_by_name("OUTPUT")


# start simulation
ctrl_sim.set_input(plaintext_pg, hal_py.BooleanFunction.Const(0, 16).get_constant_value())
ctrl_sim.set_input(key_pg, hal_py.BooleanFunction.Const(0, 16).get_constant_value())
ctrl_sim.set_input(start_net, hal_py.BooleanFunction.Value.ZERO)
ctrl_sim.simulate(30 * period)


ctrl_sim.set_input(start_net, hal_py.BooleanFunction.Value.ONE)
ctrl_sim.simulate(30 * period)


ctrl_sim.set_input(start_net, hal_py.BooleanFunction.Value.ZERO)
ctrl_sim.simulate(30 * period)


ctrl_sim.set_input(key_pg, hal_py.BooleanFunction.Const(0xFFFF, 16).get_constant_value())
ctrl_sim.set_input(start_net, hal_py.BooleanFunction.Value.ONE)
ctrl_sim.simulate(30 * period)


ctrl_sim.set_input(start_net, hal_py.BooleanFunction.Value.ZERO)
ctrl_sim.simulate(30 * period)


ctrl_sim.initialize()
ctrl_sim.run_simulation()
   
     
while eng.get_state() > 0 and eng.get_state() != 2:
    print ("eng state running %d" % (eng.get_state())) # Output: 1
    time.sleep(1)


    
print ("final state %d" % (eng.get_state())) # Output: 0 on success, -1 on error
ctrl_sim.get_results()


ctrl_sim.add_waveform_group("KEY", key_pg)
ctrl_sim.add_waveform_group("PLAINTEXT", plaintext_pg)
ctrl_sim.add_waveform_group("CIPHERTEXT", output_pg)
ctrl_sim.add_waveform_group("START", [start_net])
ctrl_sim.add_waveform_group("CLK", [clk_net])
ctrl_sim.add_waveform_group("DONE", [done_net])